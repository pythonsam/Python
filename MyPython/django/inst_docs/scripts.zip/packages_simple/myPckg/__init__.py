print("INIT file executed")

#from .subPckg import smod1


def f1():
    print("From f1 of mod2")

def f2():
    print("From f2 of mod2")
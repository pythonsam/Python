

def f1():
    print("From f1 of mod1")

def f2():
    print("From f2 of mod1")
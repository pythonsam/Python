
def f3():
    print("From f3 of sub folder smod1")


# Importing modules from the package
from myPckg import mod1, mod2
from myPckg.subPckg import smod1

# Accessing internal properties from the modules
mod1.f1()
mod1.f2()

mod2.f1()
mod2.f2()

smod1.f3()
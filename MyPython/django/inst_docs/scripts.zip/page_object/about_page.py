import sele_refer as refer


class AboutPage():
    """
    This class acts on About page of the site
    """

    def __init__(self, driver):
        self.driver = driver
        self.page_addr = "https://www.python.org/about"

    def open_page(self):
        self.driver.get(self.page_addr)
        print("\nIn About page")

    def do_get_sections_in_the_page(self):
        elements = self.driver.find_elements_by_xpath(refer.ABOUT_PAGE_SECTIONS)
        
        count = 1
        for section in elements:
            section = self.driver.find_element_by_xpath("%s/div[%d]/h2"%(refer.ABOUT_PAGE_SECTIONS, count))
            print("\nIn section: %s"%(section.text))
            links_path = "%s/div[%d]/ul"%(refer.ABOUT_PAGE_SECTIONS, count)
            print("Available links are:")
            self.get_links_in_each_section(links_path)
            count += 1

    def get_links_in_each_section(self, path):
        links = self.driver.find_element_by_xpath(path)
        print(links.text)


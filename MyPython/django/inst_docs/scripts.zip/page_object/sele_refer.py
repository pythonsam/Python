DOWNLOADS_XP = '//*[@id="downloads"]/a'
ABOUT_XP = '//*[@id="about"]/a'

ABOUT_PAGE_SECTIONS = '//div[@class="row"]'
SECTION_LINKS = "/ul"

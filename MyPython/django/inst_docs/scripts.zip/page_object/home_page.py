import os
import sele_refer as refer


class HomePage():
    """
    This class acts on Home page of the site
    """

    def __init__(self, driver):
        self.driver = driver
        self.page_addr = "https://www.python.org"

    def open_page(self):
        self.driver.get(self.page_addr)
        print("\nIn Home page")

    def do_page_test_about(self, screens_path):
        print("Verifying abouts link")
        about_elem = self.driver.find_element_by_xpath(refer.ABOUT_XP)
        about_elem.click()

        self.driver.save_screenshot(screens_path+os.path.sep+"about.png")
        self.driver.back()

    def do_page_test_downloads(self, screens_path):
        print("Verifying downloads link")
        downloads_elem = self.driver.find_element_by_xpath(refer.DOWNLOADS_XP)
        downloads_elem.click()

        self.driver.save_screenshot(screens_path+os.path.sep+"downloads.png")
        self.driver.back()

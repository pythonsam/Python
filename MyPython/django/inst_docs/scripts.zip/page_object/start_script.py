
import os
from selenium import webdriver

import home_page, about_page

# Create a new directory to store saved screenshots
cur_dir = os.getcwd()
screens_path = cur_dir + os.path.sep + "screens"

if not os.path.exists(screens_path):
    os.mkdir(screens_path)


def open_browser():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get("https://www.python.org/")
    return driver

def close_browser(driver):
    driver.quit()

if __name__ == "__main__":
    try:
        driver = open_browser()
        # Creating page objects
        home_page_obj = home_page.HomePage(driver)
        about_page_obj = about_page.AboutPage(driver)

        # Testing pages: Home page
        home_page_obj.open_page()
        home_page_obj.do_page_test_about(screens_path)
        home_page_obj.do_page_test_downloads(screens_path)

        # Testing pages: About page
        about_page_obj.open_page()
        about_page_obj.do_get_sections_in_the_page()
    except Exception as e:
        print("Exception occured: %s"%e)
    finally:
        close_browser(driver)



### SECTION -1 ##############################################################
# Direct package import
import animal.dog
import animal.cat

animal.dog.get_name()
animal.dog.shout()
animal.dog.get_legs()

animal.cat.get_name()
animal.cat.shout()
animal.cat.get_legs()

#### SECTION - 2 ##############################################################
# But each time we have to call the function starting with package name, then module name which is lengthier
# So importing the needed module now to make things shorter

from animal import dog
from animal import cat
# OR
# from animal import dog, cat

dog.get_name()
dog.shout()
dog.get_legs()

cat.get_name()
cat.shout()
cat.get_legs()

### SECTION - 3 ##############################################################
# Now it has become easier to call the  function
# Need it still easier.., import the specific function.

# from animal.dog import get_name
# from animal.dog import get_name

# But  this will have its disadvantages of name collisions. So to avoid this, we do our known work around
# i.e, give a alias/short name using 'as'

# from animal.dog import get_name as dog_get_name
# from animal.dog import get_name as cat_get_name

# dog_get_name()
# cat_get_name()

# Also we can use the '*' mechanism of importing (but not recommended due to loss of readability and name collisions)

### SECTION - 4 ##############################################################
# Until now we have relied up on the module to get the inner functionalities
# As we know to mae things little more easier, we can use __init__ to do some work, we have imported neccessary modules
# inside of it.

from animal import dog_get_name
from animal import cat_get_name
from animal import monkey_get_name

dog_get_name()
cat_get_name()
monkey_get_name() # This works because these are made available in the init script of animal package

# without init may be we could use help of module to get to the necessary function, as in SECTIONs -1 or 2 above
# and for monkey it could have been as this
# import animal.monkey_pkg.monkey
# animal.monkey_pkg.monkey.get_name()
# OR
# from animal.monkey_pkg import monkey
# monkey.get_name()
# OR
from animal.monkey_pkg.monkey import get_name, get_legs   #---> Of course we may have name collision, and so we may use 'as'
get_name()
get_legs()

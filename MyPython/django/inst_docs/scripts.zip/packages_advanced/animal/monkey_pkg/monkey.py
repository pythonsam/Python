
NAME = "Monkey"

def get_name():
    print("I am a %s"%NAME)

def shout():
    print("%s shouting...kwaash!kwaash!!"%NAME)

def get_legs():
    print("I %s have 2 legs 2 hands"%NAME)

def get_age():
    print("I am x yrs old")
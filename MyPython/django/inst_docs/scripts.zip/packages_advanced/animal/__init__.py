print("Initializing animal package")

# From current directories dog import some function. so we use '.'
from .dog import get_name as dog_get_name
from .cat import get_name as cat_get_name

from .monkey_pkg.monkey import get_name as monkey_get_name
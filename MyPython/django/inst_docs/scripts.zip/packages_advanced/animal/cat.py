
NAME = "Cat"

def get_name():
    print("I am a %s"%NAME)

def shout():
    print("%s shouting...meow!meow!!"%NAME)

def get_legs():
    print("I %s have 4 legs"%NAME)

def get_age():
    print("I am x yrs old")
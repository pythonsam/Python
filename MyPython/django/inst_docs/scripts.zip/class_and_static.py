
class C1():
    # Class variables
    cv1 = 100

    def __init__(self):
        self.v1 = 10
        self.v2 = 20
        v3 = 30

    def inst_meth(self):
        print("From instance methods")
        self.inst_meth2()
        
    def inst_meth2(self):
        print("From instance method 2")

    @staticmethod
    def stat_method():
        # Staticmethods doesen't have self as first argument. So it can't access any 
        # properties(variables) or functionalities of a class nor can change them
        print("From static method")

    @classmethod
    def class_var_changer(cls):
        # Class methods will have the first argument as class itself which will be passed
        # by the interpreter(same as for how self is passed) when executed. These methods
        # can only access class leevl variables but not instance level variables
        cls.cv1 = 10000

# Creating 2 objects
obj1 = C1()
obj2 = C1()

# Accessing instance variables
print(obj1.v1)
print(obj2.v1)

# Change inst. variable of obj1
obj1.v1 = 15

# Acess inst. variable of obj2. Change in obj1 variable will not affect this obj2 as instance
# variables are specific to that created instance
print(obj2.v1)

print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")

# Access class variable from class
print(C1.cv1)

# Access class variable from objects
print(obj1.cv1)
print(obj2.cv1)
# Change class variable
C1.cv1 = 1000
# See the effect from the objects when accessed for class variable
print(obj1.cv1)
print(obj2.cv1)

# Class methods or Static methods can be called without creating an instance

# Call class method with object or with class
obj1.class_var_changer()
C1.class_var_changer()
print(obj1.cv1)
print(obj2.cv1)

# Call static method from object or from class
obj2.stat_method()
C1.stat_method()


